// 模擬 Next.js 首頁
export default function Home() { return <div>大里杙福興宮首頁</div>; }